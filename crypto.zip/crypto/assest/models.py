from django.db import models
from django.urls import reverse


# Create your models here.

class Assest(models.Model):
    assest_name = models.CharField(max_length=50, unique=True)
    slug = models.SlugField(max_length=100, unique=True)
    assest_image = models.ImageField(upload_to='images/assests', blank=True)

    class Meta:
        verbose_name = 'assest'
        verbose_name_plural = 'assests'

    '''def get_url(self):
            return reverse('products_by_category', args=[self.slug])'''

    def __str__(self):
        return self.assest_name



   