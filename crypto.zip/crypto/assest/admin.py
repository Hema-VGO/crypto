from django.contrib import admin
from .models import Assest

# Register your models here.

class AssestAdmin(admin.ModelAdmin):
    prepopulated_fields = {'slug': ('assest_name',)}
    list_display = ('assest_name', 'slug')



admin.site.register(Assest,AssestAdmin)



