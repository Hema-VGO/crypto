from django.shortcuts import render
from django.http import HttpResponse
from main.models import Details # ReviewRating


# Create your views here.
def home(request):
    details = Details.objects.all().filter(is_available=True).order_by('-created_date')


    context = {
        'details': details,
        
    }
   
    return render(request,'home.html',context)


    