from django import forms
from django.http import request

from .models import Account




class RegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput(attrs={
    'placeholder': 'Enter Password',
    'class':'fadeIn second',
    }))
    
    
   
    class Meta:
        model = Account
        fields = [ 'name','email', 'password','phone_number'] #'phone_number'

    def clean(self):
        cleaned_data = super(RegistrationForm, self).clean()
        password = cleaned_data.get('password')

    def __init__(self, *args, **kwargs):
        super(RegistrationForm, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs['placeholder'] = 'Enter  Name'
        self.fields['email'].widget.attrs['placeholder'] = 'Enter Email Address' 
        self.fields['phone_number'].widget.attrs['placeholder'] = 'Enter Phone Number'
        #self.fields['password'].widget.attrs['placeholder'] = 'Enter Password'
        for field in self.fields:
            self.fields[field].widget.attrs['class'] = 'fadeIn second' 
            