from django.urls import path
from .import views

urlpatterns = [
    path ('register/', views.register,name='register'),
    path ('signin/', views.signin ,name='signin'),
    path ('logout/', views.logout,name='logout'),
    path ('forgotPassword', views.forgotPassword,name='forgotPassword'),
    path('activate/<uidb64>/<token>/', views.activate, name='activate'),
    path('resetpassword_validate/<slug:uidb64>/<slug:token>/', views.resetpassword_validate, name='resetpassword_validate'),
    path ('resetPassword', views.resetPassword,name='resetPassword'), 
]