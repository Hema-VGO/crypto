from django.shortcuts import render,redirect
from .forms import RegistrationForm
from accountss.models import Account
from django.contrib import messages,auth
from django.contrib.auth.decorators import login_required

# Verification email
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import EmailMessage



# Create your views here.
def register(request):
    
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data['name']
            email = form.cleaned_data['email']
            phone_number = form.cleaned_data['phone_number']
            password = form.cleaned_data['password']
            username =name # email.split("@")[0]
            #
            user = Account.objects.create_user(name=name,email=email, username=username, password=password ,phone_number=phone_number, ) #phone_number=phone_number
            user.save()

            # USER ACTIVATION
            current_site = get_current_site(request)
            mail_subject = 'Please activate your account'
            message = render_to_string('account_verification_email.html', {
                'user': user,
                'domain': current_site,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': default_token_generator.make_token(user),
            })
            to_email = email
            send_email = EmailMessage(mail_subject, message, to=[to_email])
            send_email.send()
            #messages.success(request, 'Thank you for registering with us. We have sent you a verification email to your email address [rathan.kumar@gmail.com]. Please verify it.')
            return redirect('/accountss/signin/?command=verification&email='+email)
            
    else:
        form = RegistrationForm()
    context = {
        'form': form,
    }
    return render(request,'register.html',context)


def signin(request):
    if request.method == 'POST':
        email = request.POST.get('email') #or  name = request.POST.get('name')
        password = request.POST.get('password')

        user = auth.authenticate(email=email, password=password)

        if user is not None:
            
            auth.login(request,user)
            #messages.success(request, 'You are now logged in.')
            return redirect('home')

        else:
            messages.error(request,'invalid login credentials')
            return redirect('signin')

    return render(request,'signin.html')
    

@login_required(login_url = 'signin')
def logout(request):
    auth.logout(request)
    messages.success(request, 'You are logged out.')
    return redirect('signin')

def activate(request,uidb64,token):
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        user = Account._default_manager.get(pk=uid)
    except(TypeError, ValueError, OverflowError, Account.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        messages.success(request, 'Congratulations! Your account is activated.')
        return redirect('signin')
    else:
        messages.error(request, 'Invalid activation link')
        return redirect('register')




def forgotPassword(request):
    if request.method == 'POST':
        email = request.POST['email']
        if Account.objects.filter(email=email).exists():
            user = Account.objects.get(email__exact=email)

            # Reset password email
            current_site = get_current_site(request)
            mail_subject = 'Reset Your Password'
            message = render_to_string('reset_password_email.html', {
                'user': user,
                'domain': current_site,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': default_token_generator.make_token(user),
            })
            to_email = email
            send_email = EmailMessage(mail_subject, message, to=[to_email])
            send_email.send()

            messages.success(request, 'Password reset email has been sent to your email address.')
            return redirect('signin')
        else:
            messages.error(request, 'Account does not exist!')
            return redirect('forgotPassword')
    return render(request, 'forgotPassword.html')

def resetpassword_validate(request, uidb64, token):#
    #return HttpResponse('ok')
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        user = Account._default_manager.get(pk=uid)
    except(TypeError, ValueError, OverflowError, Account.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        request.session['uid'] = uid
        messages.success(request, 'Please reset your password')
        return redirect('resetPassword')
    else:
        messages.error(request, 'This link has been expired!')
        return redirect('signin')


def resetPassword(request):
    if request.method == 'POST':
        password = request.POST['password']
        #confirm_password = request.POST['confirm_password']
        uid = request.session.get('uid')
        user = Account.objects.get(pk=uid)
        user.set_password(password)
        user.save()
        messages.success(request, 'Password reset successful')
        return redirect('signin')
        
            
        
    else:
        return render(request, 'resetPassword.html') 