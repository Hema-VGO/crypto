from django.shortcuts import render
from main.models import Details
from django.db.models import Q

# Create your views here.
def search(request):
    
    if 'keyword' in request.GET:
        keyword=request.GET['keyword']

        if keyword:
            details = Details.objects.order_by('-created_date').filter(Q(News__icontains=keyword) | Q(Suggestion__icontains=keyword))
            
    context = {
        'details': details,
        
    }
    return render(request, 'home.html', context)