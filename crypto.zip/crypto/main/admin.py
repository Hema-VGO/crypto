from django.contrib import admin
from .models import Details

# Register your models here.
class DetailAdmin(admin.ModelAdmin):
    #list_display = ('assest_name', 'News','is_available',)
    #prepopulated_fields = {'slug': ('assest_name',)}
    search_fields   = ('product_name','price', 'SKU_CODE', )
   

admin.site.register(Details,DetailAdmin)