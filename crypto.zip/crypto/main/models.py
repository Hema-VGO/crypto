from django.db import models

# Create your models here.
from django.db import models
from assest.models import Assest
#from django.urls import reverse

SOURCE_CHOICES = (
    ('Buy', 'Buy'),
    ('Sell', 'Sell'),
    ('Hold', 'Hold'),
    ('Simply Watch', 'Simply Watch'),
    ('Not Available', 'Not Available'),

)

# Create your models here.

class Details(models.Model):
    assest_name    = models.ForeignKey(Assest, on_delete=models.CASCADE)
    assest_image   = models.ImageField(upload_to='photos/products')
    
    
    
    
    News           = models.CharField(max_length=5000,)
    fa_images      = models.ImageField(upload_to='photos/products')
    ta_images      = models.ImageField(upload_to='photos/products')
    fa_text        = models.CharField(max_length=200, )
    ta_text        = models.CharField(max_length=200,)
    Suggestion     = models.CharField(choices=SOURCE_CHOICES, max_length=200)
    is_available    = models.BooleanField(default=True)
    Publish        = models.BooleanField(default=False)
    
    created_date    = models.DateTimeField(auto_now_add=True)
    modified_date   = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = 'detail'
        verbose_name_plural = 'details'




    def __str__(self):
        return self.News
